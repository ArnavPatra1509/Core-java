
public class emp {
	static int b=0;
	int c=0;
	public emp(){
		c++;
		b++;
	}
}

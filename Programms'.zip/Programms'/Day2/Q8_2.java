
public class Q8_2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float marks=60.0f;
		if(marks>=75.0)
		{
			System.out.println("FCD");
		}
		else if(marks>=60.0)
		{
			System.out.println("FC");
		}
		else if(marks>=50.0)
		{
			System.out.println("SC");
		}
		else if(marks>=35.0)
		{
			System.out.println("PC");
		}
		else
		{
			System.out.println("FAIL");
		}
	}
	
}

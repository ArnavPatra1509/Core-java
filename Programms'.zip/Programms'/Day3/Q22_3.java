
public class Q22_3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=12;
		switch(n)
		{
		default:
			System.out.println("Default");
		case 12:
			System.out.println("12");
			break;
		case 10:
			System.out.println("10");
		}
	}

}

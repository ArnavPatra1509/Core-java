
public class elephant extends animal{

	String species;
	int tusk_length;
	
}

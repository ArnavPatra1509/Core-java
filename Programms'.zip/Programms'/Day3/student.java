class student
{
	float mark1;
	float mark2;
	String Name;
	public float avg(){
		return (mark1+mark2)/2;
	}
	public void nam()
	{
		System.out.println("Name is:"+Name);
	}
}


public class test_sb_acc1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		account1 acc=new account1(3145);
		System.out.println(acc.get_account_det());
		account1 acc1=new account1(3146,1000,9);
		System.out.println(acc1.get_account_det());
	}

}

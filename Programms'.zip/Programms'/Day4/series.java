
public class series {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method st
		int x=3;
		System.out.print(x+" ");
		for(int i=2;i<=8;i++)
		{
			x=x+i;
			System.out.print(x+" ");
		}
	}

}

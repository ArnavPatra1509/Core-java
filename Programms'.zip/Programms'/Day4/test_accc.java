
public class test_accc {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		acc ac=new acc();
		ac.setAcc_bal(1000);
		ac.setAcc_no(1234);
		System.out.println(ac.getAcc_bal());
		System.out.println(ac.getAcc_no());
	}

}


public class animal {
	String habitat;
	String food_type;
	int age;
	int iq;
	int number_of_leg;
	String date_of_joining;
	int zoo_id;
	
	public void details()
	{
		System.out.println("Habitat "+habitat+" Food type "+food_type);
	}
}


public class citi extends bank{
	public float roi()
	{
		return 8.5f;
	}
}

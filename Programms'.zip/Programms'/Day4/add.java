
public class add {

	int add1(int x, int y)
	{
		return(x+y);
	}
	int add1(int x, int y,int z)
	{
		return x+y+z;
	}
	double add1(double x, double y)
	{
		return x+y;
	}
}

import java.util.Scanner;
public class Q25_4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		add a1=new add();
		System.out.println(a1.add1(10,20));
		System.out.println(a1.add1(20,30,40));
		System.out.println(a1.add1(3.0f,2.0f));
	}
}

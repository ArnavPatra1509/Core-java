
public class bank {
	public float roi()
	{
		return 0.0f;
	}
}


public class icici extends bank {

	public float roi()
	{
		return 9.5f;
	}
}

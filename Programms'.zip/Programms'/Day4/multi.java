
public class multi {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=5,j=4;i<=7&&j<=8;i++,j=j+2)
		{
			System.out.println(i+" * "+j+" = "+i*j);
		}
	}

}


public class Q5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float x=32.0f;
		float a,b;
		a=x/10;
		b=x%10;
		System.out.println(a+" "+b);
	}

}

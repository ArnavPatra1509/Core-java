
public class Q7 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10 , c=5 , b=20;
		System.out.println(a<b);
		System.out.println(b>c);
	}

}

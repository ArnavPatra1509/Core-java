
public class Q6 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10 , c=5 , b=20;
		System.out.println((a>b)&&(a>c));
		System.out.println((a>b)||(a>c));
		System.out.println(!((a>b)||(a>c)));
	}

}

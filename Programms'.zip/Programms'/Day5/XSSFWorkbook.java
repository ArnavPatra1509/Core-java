
public class XSSFWorkbook {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		XSSFWorkbook wb=new XSSFWorkbook();
	}

}

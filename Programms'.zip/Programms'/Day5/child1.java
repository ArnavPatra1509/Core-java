package Training1;


public class child1 extends parentclass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parentclass pc=new parentclass();
		//System.out.println(pc.a);
		System.out.println(pc.b);
		System.out.println(pc.c);
		System.out.println(pc.d);
		pc.display();
	}

}
